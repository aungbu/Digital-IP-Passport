# Anchor all 10 DEMO passports — real TRUE L1 proof

Scope: **passport.truel1.com demo + TRUE L1 only.** No other nginx site,
no Besu/BlockScout restart, no change to existing settings.

What this does: deploys `PassportAnchor.sol` (chain 77777, Berlin EVM,
gas 0), approves a demo issuer key, then anchors version 1 of all 10
sample passports. Only SHA-256 digests go on-chain — no product text,
no patent text, no private data. Chain proof = integrity + time of
approval ONLY, not ownership, licence, or patent validity. All 10
samples stay labelled DEMO (DEMO-PAT-001 … DEMO-PAT-010).

## 0. Get these files onto the server first

Push this repo update to GitHub the same way as before (from the server
terminal, token only at the git password prompt — never in chat), then
`git pull` in `/tmp/Digital-IP-Passport`, or copy the `contracts/` folder
there. Then, still on the server:

```bash
cd /tmp/Digital-IP-Passport/contracts
npm i --no-audit --no-fund
```

If `npx hardhat compile` fails because the Solidity compiler download is
blocked, copy the working config from `/opt/car-truel1/contracts/` first
(spec §10 notes car-truel1 used npm solc 0.8.24 for this reason).

## 1. Day-0 chain check (read-only, no changes)

```bash
curl -s -X POST http://127.0.0.1:8545 -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"eth_chainId","params":[]}'
# expect 0x12fd1 (= 77777). If it is not 77777, STOP.
```

## 2. Keys — server terminal only, never chat, never repo

```bash
node scripts/keys.js
# Copy the two private-key lines straight into the env file below,
# on that same terminal. Then delete that terminal output.
install -m 600 /dev/null /etc/truel1/dpp.env
cat >> /etc/truel1/dpp.env <<'EOF'
TRUEL1_RPC=http://127.0.0.1:8545
CHAIN_ID=77777
EXPLORER_URL=https://explorer.truel1.com
ISSUER_PRIVATE_KEY=<paste from keys.js, server only>
RELAYER_PRIVATE_KEY=<paste from keys.js, server only>
EOF
chmod 600 /etc/truel1/dpp.env
ls -l /etc/truel1/dpp.env
# Paste back ONLY: issuer address, relayer address, chainId result.
# Never paste the private keys.
```

## 3. Compile + deploy (one contract, once)

```bash
npx hardhat compile
DPP_ENV=/etc/truel1/dpp.env npx hardhat run scripts/deploy.js --network truel1
cat deployments/truel1-77777.json
# Paste back ONLY: contract address, deploy tx, setIssuer tx.
```

## 4. Anchor all 10 (one tx each, gas 0)

```bash
DPP_ENV=/etc/truel1/dpp.env node scripts/anchor-all.js
cat anchor-results.json
# Paste back ONLY: each id + tx hash + block number.
# The script re-reads getAnchor after every tx and aborts if the
# on-chain digest does not match — a failed re-read is NOT a success.
```

Re-running `anchor-all.js` is safe: already-anchored passports with the
same digest are skipped, not re-sent. If a passport is already anchored
with a *different* digest, the script aborts at that id — do not force it.

## 5. What happens after anchoring

Explorer will then show a real transaction for each digest (search the
tx hash, not the digest alone — Blockscout indexes txs, not raw digests).
The passport website still needs its verify step updated to read
`getAnchor` via a read-only RPC proxy and link each explorer tx — that
is the next package, after these tx hashes are confirmed.
