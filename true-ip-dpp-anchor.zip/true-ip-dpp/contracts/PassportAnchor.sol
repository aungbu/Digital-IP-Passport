// SPDX-License-Identifier: MIT
// TRUE IP -> DPP AI — PassportAnchor (new work, hackathon demo)
// Anchors ONLY the SHA-256 digest of a canonical Digital Product Passport JSON.
// Stores no private data, no product text, no patent text: only digests,
// an opaque passport id, the patent-reference hash, the relation label
// and the issuer. History is append-only; a new version never deletes an old one.
// Chain proof here is integrity + time of approval ONLY —
// NOT proof of ownership, licence, or patent validity.
pragma solidity ^0.8.24;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

contract PassportAnchor is Ownable, EIP712 {
    enum Relation { NONE, REFERENCED_TECHNOLOGY, LICENSED_VERIFIED, OWNED_VERIFIED }

    struct Anchor {
        bytes32 digest;       // sha256(canonical JSON, RFC 8785)
        bytes32 sourceRef;    // keccak256("USPTO:" + patentNumber)
        bytes32 evidenceRoot; // sha256 of the SAM-cropped product image (0 if none)
        address issuer;       // the key that signed the EIP-712 message
        uint32  version;      // 1, 2, 3 ...
        uint8   relation;     // Relation
        uint64  anchoredAt;   // block.timestamp
    }

    mapping(bytes32 => Anchor) private _latest;
    mapping(bytes32 => mapping(uint32 => bytes32)) private _history;
    mapping(address => bool) public approvedIssuer;

    bytes32 private constant ANCHOR_TYPEHASH =
        keccak256("AnchorPassport(bytes32 passportId,bytes32 digest,bytes32 sourceRef,bytes32 evidenceRoot,uint8 relation,uint32 version)");

    event IssuerSet(address indexed issuer, bool approved);
    event Anchored(bytes32 indexed passportId, uint32 indexed version, bytes32 digest, bytes32 sourceRef, uint8 relation, address issuer);

    error NotApprovedIssuer(address issuer);
    error BadVersion(uint32 expected, uint32 given);
    error RelationNeedsEvidence();

    constructor(address admin) Ownable(admin) EIP712("TRUE IP-to-DPP Anchor", "1") {}

    function setIssuer(address issuer, bool approved) external onlyOwner {
        approvedIssuer[issuer] = approved;
        emit IssuerSet(issuer, approved);
    }

    /// Relayer submits; the issuer's EIP-712 signature proves who approved the passport.
    function anchorSigned(
        bytes32 passportId, bytes32 digest, bytes32 sourceRef, bytes32 evidenceRoot,
        uint8 relation, uint32 version, bytes calldata signature
    ) external {
        bytes32 structHash = keccak256(abi.encode(ANCHOR_TYPEHASH, passportId, digest, sourceRef, evidenceRoot, relation, version));
        address issuer = ECDSA.recover(_hashTypedDataV4(structHash), signature);
        if (!approvedIssuer[issuer]) revert NotApprovedIssuer(issuer);
        uint32 expected = _latest[passportId].version + 1;
        if (version != expected) revert BadVersion(expected, version);
        if (relation > uint8(Relation.REFERENCED_TECHNOLOGY) && evidenceRoot == bytes32(0)) revert RelationNeedsEvidence();
        _latest[passportId] = Anchor(digest, sourceRef, evidenceRoot, issuer, version, relation, uint64(block.timestamp));
        _history[passportId][version] = digest;
        emit Anchored(passportId, version, digest, sourceRef, relation, issuer);
    }

    function getAnchor(bytes32 passportId) external view returns (
        bytes32 digest, bytes32 sourceRef, bytes32 evidenceRoot, address issuer, uint32 version, uint8 relation, uint64 anchoredAt
    ) {
        Anchor storage a = _latest[passportId];
        return (a.digest, a.sourceRef, a.evidenceRoot, a.issuer, a.version, a.relation, a.anchoredAt);
    }

    function digestAt(bytes32 passportId, uint32 version) external view returns (bytes32) {
        return _history[passportId][version];
    }
}
