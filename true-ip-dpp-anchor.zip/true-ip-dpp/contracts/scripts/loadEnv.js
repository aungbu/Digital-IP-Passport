// Load key/value pairs from a server env file (default /etc/truel1/dpp.env).
// Never log values. Callers check only that required names are present.
import { readFileSync, existsSync } from "node:fs";

export function loadEnv(path) {
  const file = path || process.env.DPP_ENV || "/etc/truel1/dpp.env";
  if (!existsSync(file)) {
    throw new Error(
      `Env file not found: ${file}\nCreate it on the server only (600) with TRUEL1_RPC, CHAIN_ID, ISSUER_PRIVATE_KEY, RELAYER_PRIVATE_KEY. Never put keys in the repo or in chat.`
    );
  }
  for (const line of readFileSync(file, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
  return file;
}

export function requireEnv(names) {
  const missing = names.filter((n) => !process.env[n]);
  if (missing.length) throw new Error(`Missing in env file: ${missing.join(", ")}`);
}
