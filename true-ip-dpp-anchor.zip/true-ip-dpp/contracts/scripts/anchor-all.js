// Anchor all 10 DEMO passports (version 1 each) to PassportAnchor on TRUE L1.
// Reads the sample passports + local digests from the repo (web/data first,
// data/ as fallback), computes passportId/sourceRef exactly as the spec says,
// signs each anchor with the ISSUER key (EIP-712), sends it with the RELAYER
// key (legacy tx, gasPrice 0), waits for the receipt, then RE-READS getAnchor
// and only records it when the on-chain digest matches.
// Idempotent: already-anchored with the same digest = skipped, not re-sent.
// Already-anchored with a DIFFERENT digest = abort (never silently overwrite v1).
// Writes contracts/anchor-results.json (tx hash, block, explorer link per id).
// Usage: DPP_ENV=/etc/truel1/dpp.env node scripts/anchor-all.js
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ethers } from "ethers";
import { loadEnv, requireEnv } from "./loadEnv.js";

const here = dirname(fileURLToPath(import.meta.url));
const contractsRoot = join(here, "..");
const repoRoot = join(contractsRoot, "..");

function readJsonFirst(paths) {
  for (const p of paths) if (existsSync(p)) return JSON.parse(readFileSync(p, "utf8"));
  throw new Error(`None of these files found: ${paths.join(", ")}`);
}

loadEnv();
requireEnv(["TRUEL1_RPC", "ISSUER_PRIVATE_KEY", "RELAYER_PRIVATE_KEY"]);
const deploymentPath = join(contractsRoot, "deployments/truel1-77777.json");
if (!existsSync(deploymentPath)) throw new Error("Run deploy.js first — deployments/truel1-77777.json not found.");
const deployment = JSON.parse(readFileSync(deploymentPath, "utf8"));
const contractAddress = process.env.CONTRACT_ADDRESS || deployment.contract;
if (!contractAddress) throw new Error("No contract address in deployments file or CONTRACT_ADDRESS.");

const provider = new ethers.JsonRpcProvider(process.env.TRUEL1_RPC);
const chainId = Number((await provider.getNetwork()).chainId);
if (chainId !== 77777) throw new Error(`Wrong chain: expected 77777, got ${chainId}. Stop.`);

const samples = readJsonFirst([join(repoRoot, "web/data/samples.json"), join(repoRoot, "data/samples.json")]);
const digests = readJsonFirst([join(repoRoot, "web/data/digests.json"), join(repoRoot, "data/digests.json")]);
const artifact = JSON.parse(readFileSync(join(contractsRoot, "artifacts/contracts/PassportAnchor.sol/PassportAnchor.json"), "utf8"));

const issuer = new ethers.Wallet(process.env.ISSUER_PRIVATE_KEY, provider);
const relayer = new ethers.Wallet(process.env.RELAYER_PRIVATE_KEY, provider);
const contract = new ethers.Contract(contractAddress, artifact.abi, provider);
const contractAsRelayer = contract.connect(relayer);
const explorer = (process.env.EXPLORER_URL || "https://explorer.truel1.com").replace(/\/$/, "");

console.log("Contract:", contractAddress);
console.log("Issuer:", issuer.address, "| Relayer:", relayer.address);
console.log("approvedIssuer(issuer) =", await contract.approvedIssuer(issuer.address));
if (!(await contract.approvedIssuer(issuer.address))) throw new Error("Issuer is not approved. Run deploy.js (setIssuer) first.");

const domain = { name: "TRUE IP-to-DPP Anchor", version: "1", chainId: 77777, verifyingContract: contractAddress };
const types = { AnchorPassport: [
  { name: "passportId", type: "bytes32" }, { name: "digest", type: "bytes32" },
  { name: "sourceRef", type: "bytes32" }, { name: "evidenceRoot", type: "bytes32" },
  { name: "relation", type: "uint8" }, { name: "version", type: "uint32" }
]};
const ZERO = "0x0000000000000000000000000000000000000000000000000000000000000000";
const results = [];

for (const p of samples.passports) {
  const id = p.id;
  const digest = digests[id];
  if (!digest) throw new Error(`No digest in digests.json for ${id}. Stop — do not anchor a passport without its recorded digest.`);
  const passportId = ethers.keccak256(ethers.toUtf8Bytes(`TRUE-DPP:${id}`));
  const sourceRef = ethers.keccak256(ethers.toUtf8Bytes(`USPTO:${p.ipReference.number}`));
  const relation = 1; // REFERENCED_TECHNOLOGY — demo sample, no licence/ownership verified
  const version = 1;
  const existing = await contract.getAnchor(passportId);
  if (existing.version !== 0n) {
    if (existing.digest.toLowerCase() === `0x${digest}`.toLowerCase()) {
      console.log(`SKIP ${id}: already anchored v${existing.version} with the same digest.`);
      results.push({ id, passportId, digest: `0x${digest}`, sourceRef, relation, version: Number(existing.version), status: "already-anchored", note: "Re-run did not re-send; verify the tx in the earlier run's anchor-results.json." });
      continue;
    }
    throw new Error(`ABORT at ${id}: on-chain v${existing.version} has a DIFFERENT digest. Do not overwrite v1 — decide on a v2 re-approval first.`);
  }
  const message = { passportId, digest: `0x${digest}`, sourceRef, evidenceRoot: ZERO, relation, version };
  const signature = await issuer.signTypedData(domain, types, message);
  const tx = await contractAsRelayer.anchorSigned(passportId, message.digest, sourceRef, ZERO, relation, version, signature, { type: 0, gasPrice: 0, gasLimit: 400000 });
  console.log(`SENT ${id}: tx ${tx.hash} — waiting...`);
  const receipt = await tx.wait();
  const after = await contract.getAnchor(passportId);
  if (after.digest.toLowerCase() !== `0x${digest}`.toLowerCase() || after.version !== 1n) {
    throw new Error(`VERIFY FAILED for ${id} after tx ${receipt.hash}: on-chain digest/version do not match. Do not trust this anchor.`);
  }
  const row = { id, passportId, digest: `0x${digest}`, sourceRef, relation, version: 1, status: "anchored", txHash: receipt.hash, blockNumber: receipt.blockNumber, issuer: issuer.address, explorerTx: `${explorer}/tx/${receipt.hash}`, explorerContract: `${explorer}/address/${contractAddress}` };
  results.push(row);
  console.log(`ANCHORED ${id}: block ${receipt.blockNumber} ${row.explorerTx}`);
}

writeFileSync(join(contractsRoot, "anchor-results.json"), JSON.stringify({ chainId: 77777, contract: contractAddress, anchoredAt: new Date().toISOString(), results }, null, 2) + "\n");
console.log(`\nDone: ${results.length} rows written to contracts/anchor-results.json`);
console.log("Next: paste ONLY the tx hashes + block numbers back (never keys), then update the passport site to verify via getAnchor and link each explorer tx.");
