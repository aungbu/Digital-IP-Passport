// Deploy PassportAnchor to TRUE L1 (chain 77777, Berlin, gas 0) and
// approve the issuer. Run AFTER `npx hardhat compile` on the server.
// Writes contracts/deployments/truel1-77777.json (address + tx, public).
// Usage: DPP_ENV=/etc/truel1/dpp.env npx hardhat run scripts/deploy.js --network truel1
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { ethers } from "ethers";
import { loadEnv, requireEnv } from "./loadEnv.js";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..");
loadEnv();
requireEnv(["TRUEL1_RPC", "RELAYER_PRIVATE_KEY", "ISSUER_PRIVATE_KEY"]);

const provider = new ethers.JsonRpcProvider(process.env.TRUEL1_RPC);
const chainId = Number(await provider.getNetwork().then((n) => n.chainId));
if (chainId !== 77777) throw new Error(`Wrong chain: expected 77777, got ${chainId}. Stop — do not deploy to another chain.`);

const relayer = new ethers.Wallet(process.env.RELAYER_PRIVATE_KEY, provider);
const issuer = new ethers.Wallet(process.env.ISSUER_PRIVATE_KEY, provider);
console.log("Relayer (deployer):", relayer.address);
console.log("Issuer (to approve):", issuer.address);

const artifact = JSON.parse(readFileSync(join(root, "artifacts/contracts/PassportAnchor.sol/PassportAnchor.json"), "utf8"));
const factory = new ethers.ContractFactory(artifact.abi, artifact.bytecode, relayer);
const contract = await factory.deploy(relayer.address, { type: 0, gasPrice: 0, gasLimit: 3000000 });
const receipt = await contract.deploymentTransaction().wait();
const address = await contract.getAddress();
console.log("PassportAnchor deployed at:", address);
console.log("Deploy tx:", receipt.hash, "block:", receipt.blockNumber);

const tx = await contract.setIssuer(issuer.address, true, { type: 0, gasPrice: 0, gasLimit: 400000 });
const txReceipt = await tx.wait();
console.log("setIssuer tx:", txReceipt.hash, "block:", txReceipt.blockNumber);
console.log("approvedIssuer(issuer) =", await contract.approvedIssuer(issuer.address));

mkdirSync(join(root, "deployments"), { recursive: true });
const out = {
  chainId: 77777, contract: address, deployTx: receipt.hash, deployBlock: receipt.blockNumber,
  setIssuerTx: txReceipt.hash, issuer: issuer.address, relayer: relayer.address,
  explorer: `${process.env.EXPLORER_URL || "https://explorer.truel1.com"}/address/${address}`,
  note: "DEMO anchor contract for the 10 sample passports. Integrity proof only — not ownership, licence or patent validity."
};
writeFileSync(join(root, "deployments/truel1-77777.json"), JSON.stringify(out, null, 2) + "\n");
console.log("Wrote deployments/truel1-77777.json");
