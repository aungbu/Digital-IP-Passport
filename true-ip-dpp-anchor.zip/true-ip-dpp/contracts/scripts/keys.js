// Generate demo issuer + relayer keys. RUN ON THE SERVER ONLY.
// Prints addresses and private keys to YOUR terminal only.
// Copy the private keys straight into /etc/truel1/dpp.env (600) on that
// same terminal. Never paste them into chat, the repo, or the website.
// Gas is 0 on TRUE L1, so neither key needs a funded balance.
import { Wallet } from "ethers";

const issuer = Wallet.createRandom();
const relayer = Wallet.createRandom();
console.log("ISSUER address (approve this one with setIssuer):", issuer.address);
console.log("RELAYER address (deploys the contract and sends the txs):", relayer.address);
console.log("\n--- COPY THE TWO LINES BELOW INTO /etc/truel1/dpp.env ONLY, THEN DELETE THIS OUTPUT ---");
console.log(`ISSUER_PRIVATE_KEY=${issuer.privateKey}`);
console.log(`RELAYER_PRIVATE_KEY=${relayer.privateKey}`);
console.log("--- END — do not share, commit, or paste these anywhere else ---");
