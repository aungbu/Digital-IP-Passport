// Hardhat config for TRUE L1 (chain 77777, Besu, Berlin EVM, gas 0).
// Copy the working car-truel1 config over this file if the Solidity
// compiler download is blocked on your server — the spec notes that
// car-truel1 used npm solc@0.8.24 for exactly that reason.
// No keys in this file. Keys live only in /etc/truel1/dpp.env (600).
export default {
  solidity: {
    version: "0.8.24",
    settings: { evmVersion: "berlin", optimizer: { enabled: true, runs: 200 } }
  },
  networks: {
    truel1: {
      url: process.env.TRUEL1_RPC || "http://127.0.0.1:8545",
      chainId: 77777,
      gasPrice: 0
    }
  }
};
